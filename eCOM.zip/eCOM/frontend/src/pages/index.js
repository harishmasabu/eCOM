export { default as Login } from "./Login";
export { default as Register } from "./Register";
export { default as Cart } from "./Cart";
export { default as DetailPage } from "./DetailPage";
