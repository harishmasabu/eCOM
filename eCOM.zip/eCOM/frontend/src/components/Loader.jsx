import React from "react";

const Loader = () => {
  return <span className="loader"></span>;
};

export default Loader;
